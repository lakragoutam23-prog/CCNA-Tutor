// Client-side auth helpers (no external dependencies)
export const authClient = {
    // Empty client - auth is handled server-side
};
