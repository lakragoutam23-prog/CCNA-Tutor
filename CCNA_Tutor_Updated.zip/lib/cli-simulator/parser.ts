/**
 * DEPRECATED
 * 
 * This file previously contained hardcoded CLI commands.
 * The simulator now uses the AI interpreter in @/lib/cli-simulator/ai-interpreter.ts
 * served via the API endpoint at @/app/api/cli/route.ts
 */

export { };
